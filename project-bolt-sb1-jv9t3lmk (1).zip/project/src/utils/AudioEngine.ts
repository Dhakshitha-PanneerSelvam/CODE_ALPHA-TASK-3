class AudioEngine {
  private audioContext: AudioContext | null = null;
  private currentSequence: any[] = [];
  private isPlaying: boolean = false;
  private currentTimeout: number | null = null;

  constructor() {
    this.initializeAudio();
  }

  private initializeAudio() {
    try {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch (error) {
      console.error('Web Audio API is not supported in this browser');
    }
  }

  loadSequence(sequence: any[]) {
    this.currentSequence = sequence;
  }

  play() {
    if (!this.audioContext || this.currentSequence.length === 0) return;

    if (this.audioContext.state === 'suspended') {
      this.audioContext.resume();
    }

    this.isPlaying = true;
    this.playSequence();
  }

  private playSequence() {
    if (!this.isPlaying || !this.audioContext) return;

    this.currentSequence.forEach((note, index) => {
      const timeout = setTimeout(() => {
        if (this.isPlaying && this.audioContext) {
          this.playNote(note.frequency, note.duration, note.velocity / 127);
        }
      }, index * 200); // 200ms between notes

      if (index === 0) {
        this.currentTimeout = timeout;
      }
    });
  }

  private playNote(frequency: number, duration: number, volume: number = 0.5) {
    if (!this.audioContext) return;

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);

    oscillator.frequency.value = frequency;
    oscillator.type = 'sine';

    // Envelope
    const now = this.audioContext.currentTime;
    gainNode.gain.setValueAtTime(0, now);
    gainNode.gain.linearRampToValueAtTime(volume * 0.3, now + 0.01);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + duration);

    oscillator.start(now);
    oscillator.stop(now + duration);
  }

  pause() {
    this.isPlaying = false;
    if (this.currentTimeout) {
      clearTimeout(this.currentTimeout);
      this.currentTimeout = null;
    }
  }

  stop() {
    this.pause();
    // Reset playback position if needed
  }

  getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export default AudioEngine;