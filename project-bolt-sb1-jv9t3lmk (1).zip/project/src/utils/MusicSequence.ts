interface Note {
  note: string;
  pitch: number;
  frequency: number;
  duration: number;
  velocity: number;
  time: number;
}

interface GenerationSettings {
  style: string;
  tempo: number;
  key: string;
  scale: string;
  complexity: number;
  duration: number;
}

class MusicSequence {
  private scales: { [key: string]: number[] } = {
    major: [0, 2, 4, 5, 7, 9, 11],
    minor: [0, 2, 3, 5, 7, 8, 10],
    dorian: [0, 2, 3, 5, 7, 9, 10],
    mixolydian: [0, 2, 4, 5, 7, 9, 10]
  };

  private noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

  generate(settings: GenerationSettings): Note[] {
    const sequence: Note[] = [];
    const numNotes = Math.floor((settings.duration * settings.tempo) / 60 * 2); // Approximate notes based on tempo
    
    const baseOctave = 4;
    const keyIndex = this.noteNames.indexOf(settings.key);
    const scaleIntervals = this.scales[settings.scale];
    
    let currentTime = 0;
    const noteDuration = 60 / settings.tempo; // Quarter note duration in seconds

    for (let i = 0; i < numNotes; i++) {
      const note = this.generateNote(settings, keyIndex, scaleIntervals, baseOctave, currentTime, noteDuration);
      sequence.push(note);
      currentTime += noteDuration * this.getNoteDurationMultiplier(settings.complexity);
    }

    return sequence;
  }

  private generateNote(
    settings: GenerationSettings, 
    keyIndex: number, 
    scaleIntervals: number[], 
    baseOctave: number, 
    time: number, 
    baseDuration: number
  ): Note {
    // Select note from scale
    const scaleIndex = Math.floor(Math.random() * scaleIntervals.length);
    const semitoneOffset = scaleIntervals[scaleIndex];
    
    // Add octave variation based on complexity
    const octaveVariation = Math.floor((Math.random() - 0.5) * (settings.complexity / 5));
    const octave = baseOctave + octaveVariation;
    
    // Calculate MIDI note number
    const midiNote = (octave + 1) * 12 + keyIndex + semitoneOffset;
    const pitch = Math.max(0, Math.min(127, midiNote));
    
    // Calculate frequency
    const frequency = 440 * Math.pow(2, (pitch - 69) / 12);
    
    // Generate velocity based on style
    const velocity = this.getVelocityForStyle(settings.style, settings.complexity);
    
    // Calculate duration with some variation
    const durationMultiplier = this.getNoteDurationMultiplier(settings.complexity);
    const duration = baseDuration * durationMultiplier;
    
    // Get note name
    const noteName = this.noteNames[(pitch) % 12];
    const octaveNum = Math.floor(pitch / 12) - 1;
    
    return {
      note: `${noteName}${octaveNum}`,
      pitch,
      frequency,
      duration,
      velocity,
      time
    };
  }

  private getVelocityForStyle(style: string, complexity: number): number {
    const baseVelocity = {
      classical: 80,
      jazz: 90,
      ambient: 60,
      electronic: 100
    }[style] || 80;

    // Add some randomness based on complexity
    const variation = (Math.random() - 0.5) * complexity * 5;
    return Math.max(40, Math.min(127, baseVelocity + variation));
  }

  private getNoteDurationMultiplier(complexity: number): number {
    // More complex music has more varied note durations
    const options = [0.25, 0.5, 1, 2]; // 16th, 8th, quarter, half notes
    const weights = complexity > 7 ? [0.3, 0.3, 0.3, 0.1] : [0.1, 0.2, 0.6, 0.1];
    
    const random = Math.random();
    let cumulative = 0;
    
    for (let i = 0; i < options.length; i++) {
      cumulative += weights[i];
      if (random <= cumulative) {
        return options[i];
      }
    }
    
    return 1; // Default to quarter note
  }
}

export default MusicSequence;