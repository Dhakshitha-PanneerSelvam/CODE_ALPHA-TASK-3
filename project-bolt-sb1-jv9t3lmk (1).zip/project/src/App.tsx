import React, { useState } from 'react';
import { Music, Brain, AudioWaveform as Waveform, Settings } from 'lucide-react';
import MusicGenerator from './components/MusicGenerator';
import EducationSection from './components/EducationSection';
import Header from './components/Header';

function App() {
  const [activeTab, setActiveTab] = useState<'generate' | 'learn'>('generate');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900/20 to-gray-900 text-white">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        {/* Navigation */}
        <div className="flex justify-center mb-8">
          <div className="flex bg-gray-800/50 backdrop-blur-sm rounded-xl p-1 border border-gray-700/50">
            <button
              onClick={() => setActiveTab('generate')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-all duration-300 ${
                activeTab === 'generate'
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
              }`}
            >
              <Music className="w-5 h-5" />
              Generate Music
            </button>
            <button
              onClick={() => setActiveTab('learn')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-all duration-300 ${
                activeTab === 'learn'
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
              }`}
            >
              <Brain className="w-5 h-5" />
              Learn AI Music
            </button>
          </div>
        </div>

        {/* Content */}
        {activeTab === 'generate' ? <MusicGenerator /> : <EducationSection />}
      </div>
    </div>
  );
}

export default App;