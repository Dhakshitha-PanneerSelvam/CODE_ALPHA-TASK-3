import React from 'react';
import { Brain, Database, Cpu, FileMusic, Lightbulb, ArrowRight } from 'lucide-react';

const EducationSection: React.FC = () => {
  const steps = [
    {
      icon: Database,
      title: "Data Collection",
      description: "Collect MIDI music data from various genres including classical, jazz, electronic, and world music.",
      details: [
        "Gather diverse MIDI files from public databases",
        "Ensure quality and variety in musical styles",
        "Clean and organize the dataset",
        "Convert to standardized format"
      ]
    },
    {
      icon: Cpu,
      title: "Data Preprocessing",
      description: "Convert MIDI data into note sequences suitable for machine learning training.",
      details: [
        "Extract note information (pitch, duration, velocity)",
        "Create time-series sequences",
        "Normalize and encode musical features",
        "Split into training and validation sets"
      ]
    },
    {
      icon: Brain,
      title: "Model Architecture",
      description: "Build deep learning models using RNNs, LSTMs, or GANs to learn musical patterns.",
      details: [
        "LSTM networks for sequence modeling",
        "Transformer architectures for attention",
        "GAN networks for creative generation",
        "Ensemble methods for robust output"
      ]
    },
    {
      icon: FileMusic,
      title: "Training & Generation",
      description: "Train the model on musical data and generate new compositions.",
      details: [
        "Optimize loss functions for musical coherence",
        "Use teacher forcing for sequence learning",
        "Implement sampling strategies",
        "Fine-tune for specific musical styles"
      ]
    }
  ];

  const techniques = [
    {
      name: "Long Short-Term Memory (LSTM)",
      description: "Specialized RNN architecture that can learn long-term dependencies in musical sequences, making it ideal for capturing musical phrases and structures.",
      applications: ["Melody generation", "Harmony progression", "Rhythm patterns"]
    },
    {
      name: "Generative Adversarial Networks (GANs)",
      description: "Two neural networks competing against each other - one generates music while the other evaluates its quality, leading to increasingly realistic compositions.",
      applications: ["Style transfer", "Creative variation", "Unconventional compositions"]
    },
    {
      name: "Transformer Models",
      description: "Attention-based models that can understand relationships between distant musical elements, enabling more coherent long-form compositions.",
      applications: ["Full song generation", "Multi-instrument orchestration", "Style consistency"]
    },
    {
      name: "Variational Autoencoders (VAEs)",
      description: "Neural networks that learn compressed representations of music, allowing for smooth interpolation between different musical styles and controlled generation.",
      applications: ["Style interpolation", "Controlled generation", "Music analysis"]
    }
  ];

  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
          AI Music Generation Process
        </h2>
        <p className="text-gray-400 text-lg max-w-3xl mx-auto">
          Learn how artificial intelligence creates beautiful music through advanced machine learning techniques. 
          Explore the complete pipeline from data collection to musical composition.
        </p>
      </div>

      {/* Process Steps */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {steps.map((step, index) => (
          <div key={index} className="bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8 hover:border-purple-500/30 transition-all duration-300">
            <div className="flex items-center gap-4 mb-6">
              <div className="bg-purple-600/20 p-3 rounded-xl border border-purple-500/30">
                <step.icon className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-white">{step.title}</h3>
                <div className="text-sm text-purple-400 font-medium">Step {index + 1}</div>
              </div>
            </div>
            
            <p className="text-gray-300 mb-4">{step.description}</p>
            
            <ul className="space-y-2">
              {step.details.map((detail, detailIndex) => (
                <li key={detailIndex} className="flex items-center gap-2 text-sm text-gray-400">
                  <ArrowRight className="w-3 h-3 text-purple-400 flex-shrink-0" />
                  {detail}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* AI Techniques */}
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8">
        <div className="flex items-center gap-3 mb-8">
          <Lightbulb className="w-6 h-6 text-yellow-400" />
          <h3 className="text-2xl font-bold">AI Techniques for Music Generation</h3>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {techniques.map((technique, index) => (
            <div key={index} className="bg-gray-900/50 rounded-xl p-6 border border-gray-700/30">
              <h4 className="text-lg font-semibold text-purple-400 mb-3">{technique.name}</h4>
              <p className="text-gray-300 text-sm mb-4">{technique.description}</p>
              
              <div className="space-y-2">
                <h5 className="text-sm font-medium text-gray-400">Applications:</h5>
                <div className="flex flex-wrap gap-2">
                  {technique.applications.map((app, appIndex) => (
                    <span 
                      key={appIndex}
                      className="px-3 py-1 bg-purple-600/20 border border-purple-500/30 rounded-full text-xs text-purple-300"
                    >
                      {app}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Implementation Notes */}
      <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/30 rounded-2xl p-8">
        <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <Brain className="w-5 h-5 text-blue-400" />
          Implementation Considerations
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
          <div>
            <h4 className="font-semibold text-blue-300 mb-2">Technical Requirements</h4>
            <ul className="space-y-1 text-gray-300">
              <li>• GPU acceleration for training (CUDA/OpenCL)</li>
              <li>• Large datasets (10,000+ MIDI files)</li>
              <li>• Frameworks: TensorFlow, PyTorch, or Keras</li>
              <li>• Music processing: music21, pretty_midi</li>
              <li>• Audio synthesis: FluidSynth, TiMidity</li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-blue-300 mb-2">Challenges & Solutions</h4>
            <ul className="space-y-1 text-gray-300">
              <li>• Maintaining musical coherence over time</li>
              <li>• Balancing creativity with structure</li>
              <li>• Handling multiple instruments/voices</li>
              <li>• Generating appropriate song forms</li>
              <li>• Evaluating musical quality objectively</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EducationSection;