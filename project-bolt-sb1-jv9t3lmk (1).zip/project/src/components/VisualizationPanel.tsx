import React, { useEffect, useRef } from 'react';
import { BarChart3, AudioWaveform as Waveform, Music } from 'lucide-react';

interface VisualizationPanelProps {
  sequence: any[];
  isPlaying: boolean;
  settings: any;
}

const VisualizationPanel: React.FC<VisualizationPanelProps> = ({ 
  sequence, 
  isPlaying, 
  settings 
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  useEffect(() => {
    if (!canvasRef.current || sequence.length === 0) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const drawVisualization = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Set up gradient
      const gradient = ctx.createLinearGradient(0, 0, canvas.width, 0);
      gradient.addColorStop(0, '#8B5CF6');
      gradient.addColorStop(0.5, '#3B82F6');
      gradient.addColorStop(1, '#10B981');

      // Draw waveform
      const centerY = canvas.height / 2;
      const amplitude = canvas.height * 0.3;
      
      ctx.beginPath();
      ctx.strokeStyle = gradient;
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';

      for (let i = 0; i < sequence.length && i < canvas.width; i++) {
        const x = (i / sequence.length) * canvas.width;
        const note = sequence[i];
        const y = centerY + Math.sin(note.pitch * 0.1 + Date.now() * 0.001) * amplitude * (note.velocity / 127);
        
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      
      ctx.stroke();

      // Draw frequency bars
      const barWidth = canvas.width / 32;
      for (let i = 0; i < 32; i++) {
        const height = Math.random() * canvas.height * 0.6 * (isPlaying ? 1 : 0.3);
        const x = i * barWidth;
        
        ctx.fillStyle = `rgba(139, 92, 246, ${isPlaying ? 0.8 : 0.3})`;
        ctx.fillRect(x, canvas.height - height, barWidth - 2, height);
      }

      if (isPlaying) {
        animationRef.current = requestAnimationFrame(drawVisualization);
      }
    };

    drawVisualization();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [sequence, isPlaying]);

  return (
    <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8">
      <div className="flex items-center gap-2 mb-6">
        <Waveform className="w-5 h-5 text-purple-400" />
        <h3 className="text-lg font-semibold">Music Visualization</h3>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Waveform */}
        <div className="lg:col-span-2">
          <div className="bg-gray-900/50 rounded-xl p-4 border border-gray-700/30">
            <canvas
              ref={canvasRef}
              width={800}
              height={200}
              className="w-full h-32 rounded-lg"
            />
          </div>
        </div>

        {/* Music Info */}
        <div className="space-y-4">
          <div className="bg-gray-900/50 rounded-xl p-4 border border-gray-700/30">
            <h4 className="font-semibold mb-3 flex items-center gap-2">
              <Music className="w-4 h-4 text-purple-400" />
              Current Track
            </h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Style:</span>
                <span className="capitalize">{settings.style}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Key:</span>
                <span>{settings.key} {settings.scale}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Tempo:</span>
                <span>{settings.tempo} BPM</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Notes:</span>
                <span>{sequence.length}</span>
              </div>
            </div>
          </div>

          {/* Status */}
          <div className="bg-gray-900/50 rounded-xl p-4 border border-gray-700/30">
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-2 h-2 rounded-full ${isPlaying ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`}></div>
              <span className="text-sm font-medium">
                {isPlaying ? 'Playing' : 'Stopped'}
              </span>
            </div>
            {sequence.length > 0 && (
              <p className="text-xs text-gray-400">
                Ready to play • {Math.round(sequence.length * 0.5)}s duration
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Note Sequence Display */}
      {sequence.length > 0 && (
        <div className="mt-6">
          <h4 className="font-semibold mb-3 flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-purple-400" />
            Generated Sequence
          </h4>
          <div className="bg-gray-900/50 rounded-xl p-4 border border-gray-700/30 max-h-32 overflow-y-auto">
            <div className="flex flex-wrap gap-1">
              {sequence.slice(0, 50).map((note, index) => (
                <div
                  key={index}
                  className="px-2 py-1 bg-purple-600/20 border border-purple-500/30 rounded text-xs"
                  style={{ 
                    opacity: 0.5 + (note.velocity / 127) * 0.5,
                    backgroundColor: `hsl(${note.pitch * 3}, 60%, 30%)`
                  }}
                >
                  {note.note}
                </div>
              ))}
              {sequence.length > 50 && (
                <div className="px-2 py-1 text-xs text-gray-400">
                  +{sequence.length - 50} more notes...
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VisualizationPanel;