import React from 'react';
import { Settings, Sliders, Music2 } from 'lucide-react';

interface GenerationSettings {
  style: string;
  tempo: number;
  key: string;
  scale: string;
  complexity: number;
  duration: number;
}

interface ControlPanelProps {
  settings: GenerationSettings;
  onSettingsChange: (settings: GenerationSettings) => void;
}

const ControlPanel: React.FC<ControlPanelProps> = ({ settings, onSettingsChange }) => {
  const updateSetting = (key: keyof GenerationSettings, value: any) => {
    onSettingsChange({ ...settings, [key]: value });
  };

  const musicStyles = [
    { value: 'classical', label: '🎼 Classical', description: 'Bach-inspired compositions' },
    { value: 'jazz', label: '🎷 Jazz', description: 'Improvised progressions' },
    { value: 'ambient', label: '🌊 Ambient', description: 'Atmospheric soundscapes' },
    { value: 'electronic', label: '🎹 Electronic', description: 'Synthesized melodies' }
  ];

  const keys = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const scales = [
    { value: 'major', label: 'Major' },
    { value: 'minor', label: 'Minor' },
    { value: 'dorian', label: 'Dorian' },
    { value: 'mixolydian', label: 'Mixolydian' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Settings className="w-5 h-5 text-purple-400" />
        <h3 className="text-lg font-semibold">Generation Parameters</h3>
      </div>

      {/* Music Style */}
      <div>
        <label className="block text-sm font-medium text-gray-300 mb-3">Music Style</label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {musicStyles.map((style) => (
            <button
              key={style.value}
              onClick={() => updateSetting('style', style.value)}
              className={`p-4 rounded-lg border-2 transition-all duration-300 text-left ${
                settings.style === style.value
                  ? 'border-purple-500 bg-purple-500/20 text-white'
                  : 'border-gray-600 bg-gray-700/30 text-gray-300 hover:border-gray-500'
              }`}
            >
              <div className="font-medium">{style.label}</div>
              <div className="text-xs text-gray-400 mt-1">{style.description}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Controls Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Tempo */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Tempo: {settings.tempo} BPM
          </label>
          <input
            type="range"
            min="60"
            max="180"
            value={settings.tempo}
            onChange={(e) => updateSetting('tempo', parseInt(e.target.value))}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>60</span>
            <span>180</span>
          </div>
        </div>

        {/* Key */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Key</label>
          <select
            value={settings.key}
            onChange={(e) => updateSetting('key', e.target.value)}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:border-purple-500 focus:outline-none"
          >
            {keys.map(key => (
              <option key={key} value={key}>{key}</option>
            ))}
          </select>
        </div>

        {/* Scale */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Scale</label>
          <select
            value={settings.scale}
            onChange={(e) => updateSetting('scale', e.target.value)}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:border-purple-500 focus:outline-none"
          >
            {scales.map(scale => (
              <option key={scale.value} value={scale.value}>{scale.label}</option>
            ))}
          </select>
        </div>

        {/* Complexity */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Complexity: {settings.complexity}/10
          </label>
          <input
            type="range"
            min="1"
            max="10"
            value={settings.complexity}
            onChange={(e) => updateSetting('complexity', parseInt(e.target.value))}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>Simple</span>
            <span>Complex</span>
          </div>
        </div>

        {/* Duration */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Duration: {settings.duration}s
          </label>
          <input
            type="range"
            min="15"
            max="120"
            step="15"
            value={settings.duration}
            onChange={(e) => updateSetting('duration', parseInt(e.target.value))}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>15s</span>
            <span>120s</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ControlPanel;