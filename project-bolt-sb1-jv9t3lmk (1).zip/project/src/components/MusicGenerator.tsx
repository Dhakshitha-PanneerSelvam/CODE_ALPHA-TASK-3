import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Play, Pause, Square, Download, RefreshCw, Volume2 } from 'lucide-react';
import AudioEngine from '../utils/AudioEngine';
import MusicSequence from '../utils/MusicSequence';
import VisualizationPanel from './VisualizationPanel';
import ControlPanel from './ControlPanel';

interface GenerationSettings {
  style: string;
  tempo: number;
  key: string;
  scale: string;
  complexity: number;
  duration: number;
}

const MusicGenerator: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentSequence, setCurrentSequence] = useState<any[]>([]);
  const [settings, setSettings] = useState<GenerationSettings>({
    style: 'classical',
    tempo: 120,
    key: 'C',
    scale: 'major',
    complexity: 5,
    duration: 30
  });
  
  const audioEngine = useRef<AudioEngine | null>(null);
  const musicSequence = useRef<MusicSequence | null>(null);

  useEffect(() => {
    audioEngine.current = new AudioEngine();
    musicSequence.current = new MusicSequence();
    
    return () => {
      audioEngine.current?.stop();
    };
  }, []);

  const generateMusic = useCallback(async () => {
    if (!musicSequence.current || !audioEngine.current) return;
    
    setIsGenerating(true);
    
    // Simulate AI processing time
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    try {
      const sequence = musicSequence.current.generate(settings);
      setCurrentSequence(sequence);
      audioEngine.current.loadSequence(sequence);
    } catch (error) {
      console.error('Music generation failed:', error);
    } finally {
      setIsGenerating(false);
    }
  }, [settings]);

  const togglePlayback = useCallback(() => {
    if (!audioEngine.current) return;
    
    if (isPlaying) {
      audioEngine.current.pause();
    } else {
      audioEngine.current.play();
    }
    setIsPlaying(!isPlaying);
  }, [isPlaying]);

  const stopPlayback = useCallback(() => {
    if (!audioEngine.current) return;
    
    audioEngine.current.stop();
    setIsPlaying(false);
  }, []);

  const downloadMidi = useCallback(() => {
    if (currentSequence.length === 0) return;
    
    // Create a simple MIDI-like data structure
    const midiData = {
      tracks: [{
        name: 'AI Generated Track',
        notes: currentSequence,
        tempo: settings.tempo,
        key: settings.key,
        scale: settings.scale
      }]
    };
    
    const dataStr = JSON.stringify(midiData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `ai-music-${Date.now()}.json`;
    link.click();
    
    URL.revokeObjectURL(url);
  }, [currentSequence, settings]);

  return (
    <div className="space-y-8">
      {/* Main Controls */}
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="flex-1">
            <h2 className="text-2xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Music Generation Studio
            </h2>
            
            <ControlPanel settings={settings} onSettingsChange={setSettings} />
            
            {/* Generation Button */}
            <div className="mt-8">
              <button
                onClick={generateMusic}
                disabled={isGenerating}
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-4 px-8 rounded-xl transition-all duration-300 flex items-center justify-center gap-3 shadow-lg hover:shadow-xl disabled:cursor-not-allowed group"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    Generating AI Music...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-5 h-5 group-hover:rotate-180 transition-transform duration-500" />
                    Generate New Music
                  </>
                )}
              </button>
            </div>
          </div>
          
          {/* Playback Controls */}
          <div className="lg:w-80">
            <div className="bg-gray-900/50 rounded-xl p-6 border border-gray-700/30">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Volume2 className="w-5 h-5 text-purple-400" />
                Playback Controls
              </h3>
              
              <div className="flex items-center justify-center gap-4 mb-6">
                <button
                  onClick={togglePlayback}
                  disabled={currentSequence.length === 0}
                  className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 text-white p-4 rounded-full transition-all duration-300 shadow-lg hover:shadow-xl disabled:cursor-not-allowed"
                >
                  {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                </button>
                
                <button
                  onClick={stopPlayback}
                  disabled={currentSequence.length === 0}
                  className="bg-gray-600 hover:bg-gray-700 disabled:bg-gray-700 text-white p-4 rounded-full transition-all duration-300"
                >
                  <Square className="w-6 h-6" />
                </button>
                
                <button
                  onClick={downloadMidi}
                  disabled={currentSequence.length === 0}
                  className="bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white p-4 rounded-full transition-all duration-300 shadow-lg hover:shadow-xl disabled:cursor-not-allowed"
                >
                  <Download className="w-6 h-6" />
                </button>
              </div>
              
              {currentSequence.length > 0 && (
                <div className="text-center text-sm text-gray-400">
                  <p>{currentSequence.length} notes generated</p>
                  <p>Duration: ~{Math.round(currentSequence.length * 0.5)}s</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Visualization */}
      <VisualizationPanel 
        sequence={currentSequence} 
        isPlaying={isPlaying}
        settings={settings}
      />
    </div>
  );
};

export default MusicGenerator;